
# Task 4: Sentiment Analysis
import pandas as pd
from textblob import TextBlob
import matplotlib.pyplot as plt
from wordcloud import WordCloud

# Load Amazon reviews dataset (replace path with your dataset)
df = pd.read_csv('amazon_reviews.csv')

# Clean and analyze sentiment
def get_sentiment(text):
    return TextBlob(str(text)).sentiment.polarity

df['Sentiment'] = df['reviewText'].apply(get_sentiment)
df['Sentiment_Label'] = df['Sentiment'].apply(lambda x: 'Positive' if x > 0 else 'Negative' if x < 0 else 'Neutral')

# Plot sentiment distribution
df['Sentiment_Label'].value_counts().plot(kind='bar', title='Sentiment Distribution')
plt.xlabel('Sentiment')
plt.ylabel('Count')
plt.show()

# Word cloud for positive and negative reviews
positive_text = ' '.join(df[df['Sentiment_Label'] == 'Positive']['reviewText'].dropna())
negative_text = ' '.join(df[df['Sentiment_Label'] == 'Negative']['reviewText'].dropna())

wc_pos = WordCloud(width=800, height=400, background_color='white').generate(positive_text)
wc_neg = WordCloud(width=800, height=400, background_color='black').generate(negative_text)

plt.imshow(wc_pos, interpolation='bilinear')
plt.title('Positive Reviews Word Cloud')
plt.axis('off')
plt.show()

plt.imshow(wc_neg, interpolation='bilinear')
plt.title('Negative Reviews Word Cloud')
plt.axis('off')
plt.show()
