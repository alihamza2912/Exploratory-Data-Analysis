
# Task 3: Data Visualization
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Example dataset: COVID-19 (replace with actual file path if needed)
df = pd.read_csv('https://raw.githubusercontent.com/datasets/covid-19/main/data/countries-aggregated.csv')

# Line plot of global cases
df['Date'] = pd.to_datetime(df['Date'])
world = df.groupby('Date').sum()
world[['Confirmed', 'Recovered', 'Deaths']].plot()
plt.title('Global COVID-19 Cases Over Time')
plt.xlabel('Date')
plt.ylabel('Number of Cases')
plt.grid(True)
plt.show()

# Top countries by total confirmed cases
latest = df[df['Date'] == df['Date'].max()]
top_countries = latest.groupby('Country').sum().sort_values(by='Confirmed', ascending=False).head(10)
top_countries['Confirmed'].plot(kind='bar', title='Top 10 Countries by Confirmed Cases')
plt.ylabel('Confirmed Cases')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()
