
# Task 2: Exploratory Data Analysis (EDA)
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load dataset
df = sns.load_dataset('iris')

# Display basic info
print(df.info())
print(df.describe())

# Check for nulls
print(df.isnull().sum())

# Pairplot for feature relationships
sns.pairplot(df, hue='species')
plt.show()

# Correlation heatmap
sns.heatmap(df.corr(), annot=True, cmap='coolwarm')
plt.title('Feature Correlation Heatmap')
plt.show()
